BEHRINGER USB AUDIO Driver Win64 2.8.40
---------------------------------------


1. HARDWARE Support:
--------------------
UMA25S, UCA200*, UCA202, UCA222, UFO202, UCG102, iAXE393/624/629 and many more.

*bundled with UMX series, XENYX mixers, PODCASTUDIO USB


This driver does NOT support the following BEHRINGER hardware:
C-1U, BCD2000, BCD3000.
These models have separate dedicated drivers.



2. SYSTEM & APPLICATION:
------------------------
Supported software: All apllications which use the ASIO driver model.
Supported systems:  Vista (64-bit), Windows 7 (64-bit) and Windows 8. 


3. IMPORTANT NOTES:
-------------------
-> Driver will be installed ONLY on USB port where your hardware is connected while installation!

-> After installation ALL other audio drivers are blocked on this USB port!

-> For using different drivers: Connect your USB audio hardware to a different USB port.

-> Alternative drivers which work fine with the named hardware products:
   Vista + Windows 7: ASIO4ALL (see providers homepage)


4. INSTALLATION:
----------------
-> Unzip/Open folder
-> Double-click the "Setup.exe" and follow the instructions on the screen


5. UNINSTALL:
-------------
-> Run "Setup.exe" again
-> Select "Uninstall the driver"


6. DRIVER INDICATION:
---------------------
The driver is displayed at Device Manager > USB Controllers > BEHRINGER USB AUDIO 2.8.40 


ASIO is a trademark of Steinberg Media Technologies GmbH.
Windows is a registered trademark of Microsoft Corporation in the United States and other countries.
Mac is a trademark of Apple Computer, Inc., registered in the U.S. and other countries.